package br.com.ecommerce.implementacao;

public class Teste {

}
