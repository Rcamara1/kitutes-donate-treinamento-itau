package br.com.ecommerce.util;

public interface PadraoProduto {
	public float retornarImposto();
	public float obterValorPromocao(float param);
}
