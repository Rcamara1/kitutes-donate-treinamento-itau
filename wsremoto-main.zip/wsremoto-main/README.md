# wsremoto
Ws Java 1.8
