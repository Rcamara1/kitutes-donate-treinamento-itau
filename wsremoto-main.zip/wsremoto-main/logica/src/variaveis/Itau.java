package variaveis;

public class Itau {

	public static void main(String[] args) {
		
		System.out.print("Hello world");

		
		
		
		
		
		
		
		
	} //fecha metodo

} //fecha classe
