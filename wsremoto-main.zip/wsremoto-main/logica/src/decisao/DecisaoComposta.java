package decisao;

import javax.swing.JOptionPane;

public class DecisaoComposta {

	public static void main(String[] args) {
		String nome =  JOptionPane.showInputDialog("Aluno").toUpperCase();
		float nota1 = Float.parseFloat(JOptionPane.showInputDialog("Digite nota1"));
		float nota2 = Float.parseFloat(JOptionPane.showInputDialog("Digite nota2"));
		float media = (nota1 + nota2) / 2;
		if (media >= 6) {
			System.out.println("Parabens " +nome+ " voce esta aprovado!");
		} else 	if (media <4 ) {
			System.out.println("Infelizmente, " +nome+ " voce esta reprovado!");
		} else	{
			System.out.println("Persevere, " +nome+ " voce esta de exame!");
		}
		System.out.println("Sua m�dia foi: " +media);
	}

}
