package variaveis;

public class Itau {
    /* Classe deve ter o mesmo nome do arquivo
	* Todo metodo seguido de parenteses
	*/
		
	public static void main(String[] args) {
		
		System.out.print("Ol� mundo");
		
		
		
		
		
		
		
		
		
	} // fecha metodo

} // fecha classe
