package br.com.BANKOFOZ.util;

public interface PadraoConta {
	
	public boolean sacar(float param);
	public boolean depositar(float param);

}
