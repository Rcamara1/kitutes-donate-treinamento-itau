# wsremoto
Workspace - preparada para Jana 1.8
Gerando material para programação orientada a objeto.
