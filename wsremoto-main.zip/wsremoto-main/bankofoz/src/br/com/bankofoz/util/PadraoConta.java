package br.com.bankofoz.util;

public interface PadraoConta {
	
	public boolean sacar(float valor1);
	public boolean depositar(float valor2);
}
