package br.com.colecoes.util;

public interface PadraoProduto {
	public float retornarImposto();
	public float obterValorPromocao(float param);
}
