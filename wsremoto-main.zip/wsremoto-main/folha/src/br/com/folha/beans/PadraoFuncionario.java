package br.com.folha.beans;

public interface PadraoFuncionario {

	float calcularSalario();

}